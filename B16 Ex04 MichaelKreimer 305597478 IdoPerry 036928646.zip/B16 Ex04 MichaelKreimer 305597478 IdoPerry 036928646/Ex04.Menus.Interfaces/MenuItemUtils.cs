﻿namespace Ex04.Menus.Interfaces
{
    public class MenuItemUtils
    {
        public enum eMenuAction
        {
            ShowVersion,
            CountChars,
            CountSpace,
            ShowDate,
            ShowTime
        }
    }
}
