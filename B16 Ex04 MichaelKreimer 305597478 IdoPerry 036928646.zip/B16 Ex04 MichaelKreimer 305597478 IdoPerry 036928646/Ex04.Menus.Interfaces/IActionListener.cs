﻿namespace Ex04.Menus.Interfaces
{
    public interface IActionListener
    {
        void OnSelect(int i_Id);
    }
}
